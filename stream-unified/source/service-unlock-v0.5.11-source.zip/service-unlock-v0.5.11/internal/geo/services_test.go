// MIT License; Copyright (c) 2026 Remnawave. All transport is injected/offline.
package geo

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"reflect"
	"serviceunlock/internal/netx"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

type tripFunc func(*http.Request) (*http.Response, error)

func (f tripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

type fixture struct {
	ID, Name, Kind, URL, Method, Body, Value string
	Headers                                  map[string]string
	RequestForm                              map[string]string `json:"request_form"`
	RequestJSON                              json.RawMessage   `json:"request_json"`
	ResponseHeaders                          http.Header       `json:"response_headers"`
}

func fixtures(t *testing.T) []fixture {
	t.Helper()
	data, err := os.ReadFile("testdata/services.json")
	if err != nil {
		t.Fatal(err)
	}
	var f struct{ Checks []fixture }
	if err = json.Unmarshal(data, &f); err != nil {
		t.Fatal(err)
	}
	return f.Checks
}
func response(req *http.Request, status int, body string, headers http.Header) *http.Response {
	if headers == nil {
		headers = make(http.Header)
	}
	return &http.Response{StatusCode: status, Body: io.NopCloser(strings.NewReader(body)), ContentLength: -1, Header: headers, Request: req}
}
func environment(t *testing.T, f tripFunc) *Env {
	t.Helper()
	stack, err := netx.New(context.Background(), netx.Options{Timeout: time.Second})
	if err != nil {
		t.Fatal(err)
	}
	stack.HTTP(0).Transport = f
	t.Cleanup(stack.Close)
	return &Env{Stack: stack}
}
func single(t *testing.T, c Check, f tripFunc) Result {
	t.Helper()
	return Run(context.Background(), environment(t, f), []Check{c}, 1)[0]
}
func check(t *testing.T, id string) Check {
	t.Helper()
	for _, c := range ServiceChecks() {
		if c.ID == id {
			return c
		}
	}
	t.Fatal(id)
	return Check{}
}
func TestAll12CatalogueTypesMethodsPayloadsAndParsers(t *testing.T) {
	fs, checks := fixtures(t), ServiceChecks()
	if len(fs) != 12 || len(checks) != 12 {
		t.Fatal("not 12")
	}
	for i, c := range checks {
		f := fs[i]
		t.Run(c.ID, func(t *testing.T) {
			if c.ID != f.ID || c.Name != f.Name || c.Kind.String() != f.Kind || c.Group != GroupServices {
				t.Fatalf("catalogue mismatch: %+v %+v", c, f)
			}
			calls := 0
			auxCalls := 0
			r := single(t, c, func(req *http.Request) (*http.Response, error) {
				for _, meta := range metadataCases {
					if req.URL.String() == meta.url {
						auxCalls++
						if req.Method != meta.method {
							t.Errorf("auxiliary method mismatch")
						}
						return response(req, 200, meta.body, nil), nil
					}
				}
				calls++
				if req.URL.String() != f.URL || req.Method != f.Method {
					t.Errorf("endpoint/method mismatch: %s %s", req.Method, req.URL)
				}
				for key, value := range f.Headers {
					if req.Header.Get(key) != value {
						t.Errorf("%s header changed", key)
					}
				}
				if !strings.Contains(req.Header.Get("User-Agent"), "Chrome/151.0.0.0") {
					t.Error("upstream UA lost")
				}
				if req.Header.Get("Authorization") != "" {
					t.Error("user credential attached")
				}
				var body []byte
				if req.Body != nil {
					body, _ = io.ReadAll(req.Body)
				}
				if len(f.RequestJSON) > 0 {
					var actual, want any
					json.Unmarshal(body, &actual)
					json.Unmarshal(f.RequestJSON, &want)
					if !reflect.DeepEqual(actual, want) {
						t.Error("POST JSON differs", string(body))
					}
				} else if len(f.RequestForm) > 0 {
					form, err := url.ParseQuery(string(body))
					if err != nil {
						t.Fatal(err)
					}
					actual := map[string]string{}
					for key, values := range form {
						if len(values) != 1 {
							t.Error("duplicate form value")
						}
						actual[key] = form.Get(key)
					}
					if !reflect.DeepEqual(actual, f.RequestForm) {
						t.Error("POST validation form differs")
					}
				} else if len(body) > 0 {
					t.Error("unexpected payload")
				}
				return response(req, 200, f.Body, f.ResponseHeaders), nil
			})
			wantAux := 0
			if c.ID == "spotify_signup" || c.ID == "reddit_guest" {
				wantAux = 1
			}
			if auxCalls != wantAux || wantAux == 1 && r.Region != "JP" {
				t.Fatal("aux metadata", auxCalls, r.Region)
			}
			if calls != 1 || r.Err != nil || r.Value != f.Value || r.CheckedAt.IsZero() || r.RTT <= 0 {
				t.Fatalf("calls=%d result=%+v", calls, r)
			}
		})
	}
}
func TestAllServicesErrorsCannotBecomeObservations(t *testing.T) {
	for _, c := range ServiceChecks() {
		for _, mode := range []string{"network", "timeout", "429", "500", "503", "challenge"} {
			t.Run(c.ID+"/"+mode, func(t *testing.T) {
				r := single(t, c, func(req *http.Request) (*http.Response, error) {
					switch mode {
					case "network":
						return nil, errors.New("offline network error")
					case "timeout":
						return nil, context.DeadlineExceeded
					}
					status := 500
					switch mode {
					case "429":
						status = 429
					case "503":
						status = 503
					case "challenge":
						status = 403
					}
					return response(req, status, `cf_chl_opt unusual traffic from "en_US" "countryCode":"US" {"status":1}`, nil), nil
				})
				if r.Err == nil || r.Value != "" {
					t.Fatalf("false result: %+v", r)
				}
			})
		}
	}
}
func TestServiceSpecificRefusalAndUnknownSemantics(t *testing.T) {
	cases := []struct {
		id         string
		status     int
		body, want string
		unknown    bool
	}{
		{"google_captcha", 403, "unusual traffic from this network", "yes", false}, {"google_captcha", 200, "ordinary page", "no", false}, {"google_captcha", 403, "Forbidden", "", true},
		{"youtube_music", 403, "YouTube Music is not available in your area", "no", false},
		{"youtube_music", 200, " ", "", true},
		{"spotify_signup", 200, `{"status":120}`, "", true}, {"spotify_signup", 200, `{"status":320}`, "", true}, {"spotify_signup", 200, `{"is_country_launched":false}`, "", true},
		{"spotify_signup", 200, `{"status":"invalid"}`, "", true}, {"spotify_signup", 200, `{"is_country_launched":"invalid"}`, "", true},
		{"reddit_guest", 403, "Forbidden", "no", false}, {"reddit_guest", 404, "not found", "", true}, {"reddit_guest", 200, "", "", true},
		{"apple", 200, "US123", "", true}, {"apple", 200, "ZZ", "", true},
	}
	for _, tc := range cases {
		t.Run(tc.id+fmt.Sprint(tc.status, tc.body), func(t *testing.T) {
			r := single(t, check(t, tc.id), func(req *http.Request) (*http.Response, error) { return response(req, tc.status, tc.body, nil), nil })
			if (r.Err != nil) != tc.unknown || r.Value != tc.want {
				t.Fatalf("%+v", r)
			}
		})
	}
}
func TestYouTubeMusicCountryFromPrimaryResponse(t *testing.T) {
	const match = `ytcfg.set({"INNERTUBE_CONTEXT_GL":"JP","contentRegion":"JP"});`
	const refusal = "YouTube Music is not available in your area"
	for _, tc := range []struct {
		name, body, value, region string
		status                    int
	}{
		{"yes", match, yes, "JP", 200},
		{"no", refusal + match, no, "JP", 403},
		{"direct", `ytcfg.set({"countryCode":"US"});`, yes, "US", 200},
		{"bare-refusal", refusal, no, "", 403},
		{"conflict", `ytcfg.set({"INNERTUBE_CONTEXT_GL":"JP","contentRegion":"US"});`, yes, "", 200},
		{"bad-field", `ytcfg.set({"INNERTUBE_CONTEXT_GL":"JP","contentRegion":42,"countryCode":"JP"});`, yes, "", 200},
		{"single-context", `ytcfg.set({"INNERTUBE_CONTEXT_GL":"JP"});`, yes, "", 200},
		{"interstitial", "<title>Before you continue</title>" + match, yes, "", 200},
		{"lookalike", `{"INNERTUBE_CONTEXT_GL":"JP","contentRegion":"JP"}`, yes, "", 200},
		{"unexpected-403", match, "", "", 403},
	} {
		t.Run(tc.name, func(t *testing.T) {
			calls := 0
			r := single(t, check(t, "youtube_music"), func(req *http.Request) (*http.Response, error) {
				calls++
				if req.URL.String() != "https://music.youtube.com/" || calls != 1 {
					t.Fatal("unexpected request", req.URL, calls)
				}
				return response(req, tc.status, tc.body, nil), nil
			})
			if calls != 1 || r.Value != tc.value || r.Region != tc.region || (r.Err != nil) != (tc.value == "") {
				t.Fatalf("calls=%d result=%+v", calls, r)
			}
		})
	}
}

func TestJSONAndMissingCountryParseFailures(t *testing.T) {
	for _, id := range []string{"twitch", "spotify_signup", "deezer", "apple", "steam", "playstation", "ookla", "jetbrains", "bing"} {
		for _, body := range []string{"{}", "{broken", "", "<html>no marker</html>"} {
			r := single(t, check(t, id), func(req *http.Request) (*http.Response, error) { return response(req, 200, body, nil), nil })
			if r.Err == nil {
				t.Fatalf("%s body=%q: %+v", id, body, r)
			}
		}
	}
}
func TestUpstreamFallbacksAreExplicitAndDoNotHideHTTPFailure(t *testing.T) {
	for _, body := range []string{`Region: "WW"`, "no market"} {
		got := single(t, bing(), func(req *http.Request) (*http.Response, error) {
			if req.URL.Host == "login.live.com" {
				return response(req, 200, `"sRequestCountry":"GB"`, nil), nil
			}
			return response(req, 200, body, nil), nil
		})
		if got.Value != "GB" || !strings.Contains(got.Detail, "Microsoft account") {
			t.Fatalf("%+v", got)
		}
	}
}
func TestIndependentConcurrencyAndCancelledChecks(t *testing.T) {
	var active, peak atomic.Int32
	checks := ServiceChecks()
	env := &Env{}
	for i := range checks {
		c := &checks[i]
		kind := c.Kind
		c.Run = func(ctx context.Context, e *Env, _ netx.Family) (string, error) {
			n := active.Add(1)
			defer active.Add(-1)
			for old := peak.Load(); n > old && !peak.CompareAndSwap(old, n); old = peak.Load() {
			}
			select {
			case <-ctx.Done():
				return "", ctx.Err()
			case <-time.After(time.Millisecond):
			}
			if kind == KindCountry {
				return "US", nil
			}
			return "yes", nil
		}
	}
	got := Run(context.Background(), env, checks, 2)
	if peak.Load() != 2 || active.Load() != 0 || len(got) != 12 {
		t.Fatal(peak.Load(), active.Load())
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	for _, r := range Run(ctx, &Env{}, checks, 2) {
		if r.Err == nil {
			t.Fatal("cancelled result not unknown")
		}
	}
}
