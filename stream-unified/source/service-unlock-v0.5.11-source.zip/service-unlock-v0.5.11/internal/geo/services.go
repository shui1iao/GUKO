// Derived from remnawave/geocheck v0.3.0, commit 50e084bb3ed34b55fc6839fe0dc4bafd9fe275fc.
// MIT License; Copyright (c) 2026 Remnawave.
package geo

import (
	"context"
	"errors"
	"mime"
	"net/http"
	"regexp"
	"strings"

	"serviceunlock/internal/extra"
	"serviceunlock/internal/jsonx"
	"serviceunlock/internal/netx"
)

const (
	googleConsentCookie = "SOCS=CAISNQgDEitib3FfaWRlbnRpdHlmcm9udGVuZHVpc2VydmVyXzIwMjUwNzMwLjA1X3AwGgJlbiACGgYIgPC_xAY"

	spotifyAPIKey   = "142b583129b2df829de3656f9eb484e6"
	spotifyClientID = "9a8d2f0ce77a4e248bb71fefcb557637"

	yes = "yes"
	no  = "no"
)

var (
	reDeezerCountry = regexp.MustCompile(`'country':\s*'([^']*)'`)

	reBingRegion    = regexp.MustCompile(`Region\s*:\s*"([^"]+)"`)
	reLiveCountry   = regexp.MustCompile(`"sRequestCountry":"([^"]*)"`)
	reSteamCountry  = regexp.MustCompile(`steamCountry=([^%;]*)`)
	rePSCountry     = regexp.MustCompile(`(?i)country=([A-Za-z]{2})`)
	reGoogleBlocked = regexp.MustCompile(`(?i)unusual traffic from|is blocked|unaddressed abuse`)
)

// ServiceChecks returns the consumer-service probes, in display order.
func ServiceChecks() []Check {
	return []Check{
		googleSearchCaptcha(),
		youtubeMusic(),
		twitch(),
		spotifySignup(),
		deezer(),
		redditGuest(),
		apple(),
		steam(),
		playstation(),
		ookla(),
		jetbrains(),
		bing(),
	}
}

// googleSearchCaptcha detects whether the exit IP is flagged for abuse.
func googleSearchCaptcha() Check {
	return Check{
		ID: "google_captcha", Name: "Google", Group: GroupServices, Kind: KindBlocked,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				URL:     "https://www.google.com/search?q=cats",
				Headers: map[string]string{"Accept-Language": "en-US,en;q=0.9"},
			}, http.StatusForbidden)
			if err != nil {
				return "", err
			}
			if reGoogleBlocked.MatchString(resp.Text()) {
				return yes, nil
			}
			if !resp.OK() {
				return "", errors.New("HTTP 403 without captcha/block marker")
			}
			return no, nil
		},
	}
}

func youtubeMusic() Check {
	const home = "https://music.youtube.com/"
	const refusal = "youtube music is not available in your area"
	return Check{
		ID: "youtube_music", Name: "YouTube Music", Group: GroupServices, Kind: KindAvailability,
		runWithRegion: func(ctx context.Context, env *Env, f netx.Family) (string, string, error) {
			resp, err := env.request(ctx, f, netx.Request{URL: home, Headers: map[string]string{
				"Cookie": googleConsentCookie, "Accept-Language": "en-US,en;q=0.9",
			}}, http.StatusForbidden)
			if err != nil {
				return "", "", err
			}
			if len(resp.Body) == 0 {
				return "", "", nil
			}
			if strings.Contains(strings.ToLower(resp.Text()), refusal) {
				return no, youtubeMusicRegion(resp, home, http.StatusForbidden), nil
			}
			if !resp.OK() {
				return "", "", errors.New("unexpected HTTP 403 without refusal wording")
			}
			return yes, youtubeMusicRegion(resp, home), nil
		},
	}
}

func twitch() Check {
	return Check{
		ID: "twitch", Name: "Twitch", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				Method:  http.MethodPost,
				URL:     "https://gql.twitch.tv/gql",
				Headers: map[string]string{"Client-Id": "kimne78kx3ncx6brgo4mv6wki5h1ko"},
				JSON: `[{"operationName":"VerifyEmail_CurrentUser","variables":{},"extensions":` +
					`{"persistedQuery":{"version":1,"sha256Hash":` +
					`"f9e7dcdf7e99c314c82d8f7f725fab5f99d1df3d7359b53c9ae122deec590198"}}}]`,
			})
			if err != nil {
				return "", err
			}
			return jsonx.String(resp.Body, "0.data.requestInfo.countryCode"), nil
		},
	}
}

// fastAPIURL is Netflix's own speedtest bootstrap; it reports both the client
// location and the Open Connect target that would serve the stream.

func spotifySignup() Check {
	return Check{
		ID: "spotify_signup", Name: "Spotify signup", Group: GroupServices, Kind: KindAvailability,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			// This legacy anonymous request cannot establish account eligibility;
			// only an explicit evidenced endpoint refusal can be a scoped No.
			request := extra.SpotifySignupRequest()
			resp, err := env.request(ctx, f, request)
			if err != nil {
				return "", err
			}
			if resp.Status != http.StatusOK || resp.FinalURL != request.URL {
				return "", errors.New("Spotify signup endpoint/status changed; registration not tested")
			}
			if strings.EqualFold(strings.TrimSpace(resp.Header.Get("Cf-Mitigated")), "challenge") {
				return "", errors.New("Spotify signup endpoint challenged; registration not tested")
			}
			if contentType := resp.Header.Get("Content-Type"); contentType != "" {
				media, _, e := mime.ParseMediaType(contentType)
				if e != nil || media != "application/json" {
					return "", errors.New("unexpected Spotify signup response type; registration not tested")
				}
			}
			for _, marker := range []string{"cf_chl_opt", "_cf_chl", "just a moment", "cf-browser-verification", "enable javascript and cookies to continue"} {
				if strings.Contains(strings.ToLower(resp.Text()), marker) {
					return "", errors.New("Spotify signup challenge content; registration not tested")
				}
			}
			value, detail, err := extra.ClassifySpotifySignup(resp.Body)
			if err != nil && detail == "" {
				detail = "registration eligibility unknown: incomplete anonymous legacy request; actual registration/login not tested"
			}
			if detail != "" {
				env.note("spotify_signup", detail)
			}
			return value, err
		},
	}
}

func deezer() Check {
	return Check{
		ID: "deezer", Name: "Deezer", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{URL: "https://www.deezer.com/en/offers"})
			if err != nil {
				return "", err
			}
			if m := reDeezerCountry.FindStringSubmatch(resp.Text()); m != nil {
				return m[1], nil
			}
			return "", nil
		},
	}
}

// reddit reads the served country from the anonymous chat-widget response.
// No account token or user credential is supplied.
// reRedditCountry pulls the served country out of the chat widget's markup.
var reRedditCountry = regexp.MustCompile(`country="([A-Za-z]{2})"`)

const redditBlocked = "blocked by network security"

func redditGuest() Check {
	return Check{
		ID: "reddit_guest", Name: "Reddit guest access", Group: GroupServices, Kind: KindAvailability,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{URL: "https://www.reddit.com"}, http.StatusForbidden)
			if err != nil {
				return "", err
			}
			if resp.OK() && len(resp.Body) > 0 {
				return yes, nil
			}
			return no, nil
		},
	}
}

// apple asks the device-provisioning endpoint iOS itself uses; it answers with
// a bare country code.
func apple() Check {
	return Check{
		ID: "apple", Name: "Apple", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				URL: "https://gspe1-ssl.ls.apple.com/pep/gcc",
			})
			if err != nil {
				return "", err
			}
			return strings.TrimSpace(resp.Text()), nil
		},
	}
}

func steam() Check {
	return Check{
		ID: "steam", Name: "Steam", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				URL: "https://store.steampowered.com", HeadOnly: true,
			})
			if err != nil {
				return "", err
			}
			for _, c := range resp.Header.Values("Set-Cookie") {
				if m := reSteamCountry.FindStringSubmatch(c); m != nil {
					return m[1], nil
				}
			}
			return "", nil
		},
	}
}

func playstation() Check {
	return Check{
		ID: "playstation", Name: "PlayStation", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				URL: "https://www.playstation.com", HeadOnly: true,
			})
			if err != nil {
				return "", err
			}
			for _, c := range resp.Header.Values("Set-Cookie") {
				if strings.HasPrefix(c, "country=") {
					if m := rePSCountry.FindStringSubmatch(c); m != nil {
						return m[1], nil
					}
				}
			}
			return "", nil
		},
	}
}

func ookla() Check {
	return Check{
		ID: "ookla", Name: "Ookla Speedtest", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				URL: "https://www.speedtest.net/api/js/config-sdk",
			})
			if err != nil {
				return "", err
			}
			return jsonx.String(resp.Body, "location.countryCode"), nil
		},
	}
}

func jetbrains() Check {
	return Check{
		ID: "jetbrains", Name: "JetBrains", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{
				URL: "https://data.services.jetbrains.com/geo",
			})
			if err != nil {
				return "", err
			}
			return jsonx.String(resp.Body, "code"), nil
		},
	}
}

// bing reads the market Bing assigns. A redirect to cn.bing.com means the
// China market; a "WW" (worldwide) answer is unhelpful, so fall back to the
// Microsoft account endpoint which reports a real country.
func bing() Check {
	return Check{
		ID: "bing", Name: "Microsoft (Bing)", Group: GroupServices, Kind: KindCountry,
		Run: func(ctx context.Context, env *Env, f netx.Family) (string, error) {
			resp, err := env.request(ctx, f, netx.Request{URL: "https://www.bing.com/search?q=cats"})
			if err != nil {
				return "", err
			}
			body := resp.Text()
			if strings.Contains(body, "cn.bing.com") {
				return "CN", nil
			}
			region := ""
			if m := reBingRegion.FindStringSubmatch(body); m != nil {
				region = m[1]
			}
			if region != "" && !strings.EqualFold(region, "WW") {
				return region, nil
			}

			live, err := env.request(ctx, f, netx.Request{URL: "https://login.live.com"})
			if err != nil {
				return "", err
			}
			if m := reLiveCountry.FindStringSubmatch(live.Text()); m != nil {
				env.note("bing", "fallback: Microsoft account request country")
				return m[1], nil
			}
			return region, nil
		},
	}
}
